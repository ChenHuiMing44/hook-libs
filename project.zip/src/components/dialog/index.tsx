
import Dialog from './methods'

export default Dialog

export {
  Dialog
}
