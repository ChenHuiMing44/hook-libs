import React from 'react'

type Props = {
  action: boolean,
  enterCls: string,
  leaveCls: string,
  duration: number,
  easing: 'linear' | 'ease' | 'ease-in' | 'ease-out' | 'ease-in-out',
  onEnd?: (isFinish: boolean) => void
}
const Transition = (props: Props) => {
  return (
    <div>

    </div>
  )
}

export default Transition
