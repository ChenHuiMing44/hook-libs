export const CONTENT_TYPE = {
  // json
  json: 'application/json;charset=utf-8',

  // 表单文件请求
  form: 'application/form-data',

  www: 'application/x-www-form-urlencoded',

}
