

const useDialog = () => {

  // console.log(type)


}

export default useDialog
