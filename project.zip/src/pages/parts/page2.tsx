// @flow
import * as React from 'react'

type Props = {

}

const Page2 = (props: Props) => {
  return (
    <div>
      这个是page2页面
    </div>
  )
}

export default Page2
