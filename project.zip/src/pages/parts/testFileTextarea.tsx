import React, {useEffect, useRef, useState} from 'react'
import FileTextarea from '@/pages/parts/components/fileTextarea'
import FileTextarea1 from '@/pages/parts/components/fileTextarea1'


const TestFileTextarea = () => {
  // const targetV = useRef('[{"type":"paragraph","children":[{"text":"你好啊这个是有问题的拉"}]}]')
  const [defaultV, setDefaultV] = useState('')
  useEffect(() => {
    setTimeout(() => {
      setDefaultV?.('[{"type":"paragraph","children":[{"text":"你好啊这个是有问题的拉"}]}]')
    },3000)
  }, [])
  const [target, setTarget] = useState('')
  return (
    <div>
      <FileTextarea defaultValue={defaultV} changeJson={(v) => setTarget(v)}/>
      <hr/>
      <div>
        {target}
      </div>
    </div>
  )
}

export default TestFileTextarea
