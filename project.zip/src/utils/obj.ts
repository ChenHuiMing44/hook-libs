

export const isObj = (obj: unknown) => obj!== null && typeof obj === 'object'

/**
 * @author: hm, 2022/10/19
 * des: 判断两个对象是否相等
 */
export const isEqual = (obj1: unknown, obj2: unknown) => {

  if(!isObj(obj1) || !isObj(obj2)) {
    return false
  }
  if(obj1 === obj2) {
    return true
  }
  const keys1 = Object.keys(obj1 as object)
  const keys2 = Object.keys(obj2 as object)

  if (keys1.length !== keys2.length) {
    return false
  }
  for (let i = 0, len = keys1.length; i < len; i++) {
    if(Reflect.get(obj1 as object, keys1[i]) !== Reflect.get(obj2 as object, keys1[i])) {
      return false
    }
  }
  return true
}
