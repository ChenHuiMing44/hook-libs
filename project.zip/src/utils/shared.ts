

export const isFunction = (cb: unknown): boolean => typeof cb === 'function'

export const isArray = (arg: unknown): boolean => Array.isArray(arg)

export const isNumber = (arg: unknown): boolean => typeof arg === 'number'

export const isString = (arg: unknown): boolean => typeof arg === 'string'
