/// <reference types="vite/client" />

declare module '*.scss' {
  const classes: { [key: string]: string }
  export default classes
}


declare module 'braft-editor'
